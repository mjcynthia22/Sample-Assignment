import requests
import json
endpointUrl = "https://jsonplaceholder.typicode.com/"

class api_typicode(object):

    def get_saved_values(self):
        url = "{0}posts".format(endpointUrl)
        payload = ""
        headers = {
            'Content-Type': "application/json",
            'charset': "utf8"
        }
        print(headers)
        response = requests.request("GET", url, data=payload, headers=headers)
        try:
            data = response.json()
            print(json.dumps(data, indent=4))
            count=len(data)
            return response.status_code, count
        except:
            return response.status_code, 0

    def get_saved_values_id(self, idvalue):
        url = "{0}posts/{1}".format(endpointUrl, idvalue)
        payload = ""
        headers = {
            'Content-Type': "application/json",
            'charset': "utf8"
        }
        print(headers)
        response = requests.request("GET", url, data=payload, headers=headers)
        data = response.json()
        print(data)
        if len(data)>1:
            IDlist=[]
            for k,v in data.items():
                if k=='id':
                    IDlist.append(data['id'])
            responseid=data['id']
            responseuserid = data['userId']
            responsetitle = data['title']
            responsebody=data['body']

            idcount=len(IDlist)
            return response.status_code, idcount, responseid, responseuserid, responsetitle, responsebody
        else:
            return response.status_code, "", "", "", "", "", ""

    def add_new_value(self):
        url = "{0}posts".format(endpointUrl)
        payload = {
            'title': 'foo',
            'body': 'bar',
            'userId': 1
        }
        headers = {
            'Content-Type': "text/plain",
            'charset': 'utf8'
        }
        response = requests.request("POST", url, data=payload, headers=headers)
        data = response.json()
        print(json.dumps(data, indent=4))
        if len(data)==1:
            addedid = data["id"]
            return (str(response.status_code), addedid)
        else:
            return (str(response.status_code), "")

    def update_value(self, idvalue):
        url = "{0}posts/{1}".format(endpointUrl, idvalue)
        payloaddetails = {
            "id": 1,
            "title": "abc",
            "body": "xyz",
            "userId": 1
        }
        payload = json.dumps(payloaddetails)
        print(payload)
        headers = {
            'Content-Type': "application/json",
            'Accept': "application/json;charset=utf8"
        }
        response = requests.request("PUT", url, data=payload, headers=headers)
        print(response.text)

        data = response.json()
        print(json.dumps(data, indent=4))
        if len(data)>0:
            responseid = data['id']
            responseuserid = data['userId']
            responsetitle = data['title']
            responsebody = data['body']
            return (str(response.status_code), responseid, responseuserid, responsetitle, responsebody)
        else:
            return (str(response.status_code), "", "", "", "")

    def delete_value(self, idvalue):
        url = "{0}posts/{1}".format(endpointUrl, idvalue)
        payload = ""
        headers = {
            'Content-Type': "application/json",
            'Accept': "application/json;charset=utf8"
        }
        response = requests.request("DELETE", url, data=payload, headers=headers)
        print(response.text)
        return (response.status_code, " ")


obj = api_typicode()
# obj.get_saved_values()
# obj.get_saved_values_id(1)
# obj.get_saved_values_id("invalid")
# obj.add_new_value()
# obj.update_value(1)
obj.delete_value(1)
